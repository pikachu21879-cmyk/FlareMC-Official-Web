# FlareMC Official Website

A responsive Minecraft server website with a dark, fiery FlareMC theme, live server status, a database-backed vote form, and monthly/all-time vote leaderboards.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

1. Extract this project.
2. Open a terminal in the project folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Optional: copy `.env.example` to `.env` and change settings. The app reads environment variables supplied by your hosting platform; it does not automatically load `.env` without an additional package, so set variables in your shell/host panel.
5. Start the website:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000`.

## Environment variables

- `PORT` — web port (default `3000`)
- `HOST` — bind address (default `0.0.0.0`)
- `SERVER_IP` — Minecraft server address (default `flaremc.zanity.net:19121`)
- `DISCORD_URL` — official Discord invite
- `DATABASE_FILE` — SQLite database path (default `./data/flaremc.sqlite`)

## What works

- Responsive homepage with server IP copy buttons.
- Live status lookup through the public `api.mcsrvstat.us` status API, refreshed every 30 seconds.
- Vote submissions saved in SQLite.
- A 24-hour cooldown per normalized username.
- Monthly and all-time leaderboards.
- Basic rate limiting, security headers, username format validation, and server-side cooldown checks.
- Minecraft avatar images via `mc-heads.net`.

## Important before going public

1. **Votes on this website are website votes.** They do not automatically grant in-game items/ranks and are not sent to Minecraft listing sites. Connect a server plugin or authenticated reward bridge if you want in-game rewards.
2. **Username format is not identity verification.** This starter site validates the Java username format, but does not prove that the visitor owns the Minecraft account. For stronger protection, add Microsoft/Minecraft account authentication or a server-side verification flow, plus CAPTCHA/anti-abuse checks.
3. **One vote per username is not one vote per person.** A visitor can try other usernames. The rate limiter is a basic layer, not a complete anti-bot system.
4. **Bedrock support is not confirmed by this code.** Confirm Geyser/Floodgate or other Bedrock compatibility and the correct Bedrock port before advertising Bedrock join instructions.
5. Replace sample staff names, rules, gallery images, game mode details, and placeholder server-list links with accurate content.
6. For reliable production hosting, use a persistent disk/volume for `data/flaremc.sqlite`. If your host has ephemeral filesystems or multiple app instances, use a managed database instead of local SQLite.
7. Status lookup depends on the third-party status API and may be unavailable or cached occasionally.

## API endpoints

- `GET /api/config`
- `GET /api/status`
- `GET /api/vote/cooldown/:username`
- `POST /api/vote` with JSON `{ "username": "PlayerName" }`
- `GET /api/leaderboard?period=monthly`
- `GET /api/leaderboard?period=all`
- `GET /api/health`

## Deployment

Deploy the project to a Node.js host that supports Node 20+ and persistent storage. Set the environment variables in the host dashboard, run `npm install` during build, and use `npm start` as the start command. Attach persistent storage for the SQLite file. The site is not published to a public URL by this project archive alone.
