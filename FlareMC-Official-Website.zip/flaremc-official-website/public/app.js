const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
let serverIp = "flaremc.zanity.net:19121";
let discordUrl = "https://discord.gg/85HKV4jasU";
let toastTimer;

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function copyIp() {
  try {
    await navigator.clipboard.writeText(serverIp);
    toast("Server IP copied: " + serverIp);
  } catch {
    const temp = document.createElement("textarea");
    temp.value = serverIp;
    document.body.appendChild(temp);
    temp.select();
    const ok = document.execCommand("copy");
    temp.remove();
    toast(ok ? "Server IP copied!" : "Copy failed — " + serverIp);
  }
}
$$("[data-copy-ip]").forEach(button => button.addEventListener("click", copyIp));
$("#copyIp").addEventListener("click", copyIp);
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#navLinks");
  const open = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
});
$$(".nav-links a").forEach(link => link.addEventListener("click", () => {
  $("#navLinks").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
}));
$("#year").textContent = new Date().getFullYear();

async function loadConfig() {
  try {
    const response = await fetch("/api/config");
    if (!response.ok) return;
    const config = await response.json();
    if (config.serverIp) serverIp = config.serverIp;
    if (config.discordUrl) discordUrl = config.discordUrl;
    $("#serverIp").textContent = serverIp;
    $("#footerIp").textContent = serverIp;
    ["#discordNav", "#discordHero", "#discordFooter"].forEach(id => $(id).href = discordUrl);
  } catch {}
}
async function loadStatus() {
  const dot = $("#statusDot");
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    const data = await response.json();
    $("#statusText").textContent = data.online ? "Server Online" : (data.statusUnavailable ? "Status unavailable" : "Server Offline");
    dot.classList.toggle("offline", !data.online);
    $("#playerCount").textContent = data.online ? `${data.playersOnline} / ${data.playersMax}` : "0 / —";
    $("#serverVersion").textContent = data.version || "Unknown";
    $("#statusUpdated").textContent = "Auto-refreshes every 30 seconds";
  } catch {
    $("#statusText").textContent = "Status unavailable";
    dot.classList.add("offline");
    $("#serverVersion").textContent = "Unavailable";
  }
}
function formatTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}
async function checkCooldown(username, showFeedback = true) {
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return;
  try {
    const response = await fetch(`/api/vote/cooldown/${encodeURIComponent(username)}`);
    const data = await response.json();
    if (showFeedback) {
      const feedback = $("#voteFeedback");
      feedback.className = "form-feedback";
      feedback.textContent = data.canVote ? "You're ready to vote with this username." : `Next vote available in ${formatTime(data.remainingSeconds)}.`;
    }
  } catch {}
}
$("#username").addEventListener("input", () => {
  const username = $("#username").value.trim();
  if (/^[A-Za-z0-9_]{3,16}$/.test(username)) {
    $("#voteAvatar").src = `https://mc-heads.net/avatar/${encodeURIComponent(username)}/64`;
    checkCooldown(username);
  } else {
    $("#voteAvatar").src = "https://mc-heads.net/avatar/MHF_Steve/64";
    $("#voteFeedback").className = "form-feedback";
    $("#voteFeedback").textContent = "Enter a valid Minecraft username (3–16 characters).";
  }
});
$("#voteForm").addEventListener("submit", async event => {
  event.preventDefault();
  const username = $("#username").value.trim();
  const feedback = $("#voteFeedback");
  const button = $("#voteButton");
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
    feedback.className = "form-feedback error";
    feedback.textContent = "Use 3–16 letters, numbers, or underscores.";
    return;
  }
  button.disabled = true;
  button.textContent = "Submitting…";
  feedback.className = "form-feedback";
  feedback.textContent = "Recording your vote…";
  try {
    const response = await fetch("/api/vote", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username })
    });
    const data = await response.json();
    if (!response.ok) {
      feedback.className = "form-feedback error";
      feedback.textContent = data.remainingSeconds
        ? `Already voted. Try again in ${formatTime(data.remainingSeconds)}.`
        : (data.error || "Vote could not be recorded.");
    } else {
      feedback.className = "form-feedback success";
      feedback.textContent = `🔥 ${data.message}`;
      $("#voteAvatar").src = data.avatarUrl;
      await loadLeaderboard(activePeriod);
    }
  } catch {
    feedback.className = "form-feedback error";
    feedback.textContent = "Could not connect to the vote server. Please try again.";
  } finally {
    button.disabled = false;
    button.textContent = "Vote";
  }
});

let activePeriod = "monthly";
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}
async function loadLeaderboard(period = "monthly") {
  activePeriod = period;
  $$(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.period === period));
  const container = $("#leaderboardEntries");
  container.innerHTML = '<div class="empty-state">Loading votes…</div>';
  try {
    const response = await fetch(`/api/leaderboard?period=${period}`);
    const data = await response.json();
    if (!data.entries.length) {
      container.innerHTML = '<div class="empty-state">No votes yet — be the first to support FlareMC!</div>';
      return;
    }
    container.innerHTML = data.entries.map((entry, index) => `
      <article class="leader-card">
        <span class="rank">${["♛","②","③"][index] || `#${index + 1}`}</span>
        <img loading="lazy" src="https://mc-heads.net/avatar/${encodeURIComponent(entry.username)}/64" alt="">
        <strong title="${escapeHtml(entry.username)}">${escapeHtml(entry.username)}</strong>
        <small>${entry.votes} ${entry.votes === 1 ? "vote" : "votes"}</small>
      </article>`).join("");
  } catch {
    container.innerHTML = '<div class="empty-state">Leaderboard is temporarily unavailable.</div>';
  }
}
$$(".tab").forEach(tab => tab.addEventListener("click", () => loadLeaderboard(tab.dataset.period)));
$$("[data-placeholder]").forEach(link => link.addEventListener("click", event => {
  event.preventDefault();
  toast("This listing link is a placeholder. Add your real vote URL before launch.");
}));
loadConfig();
loadStatus();
loadLeaderboard();
setInterval(loadStatus, 30000);
