const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "0.0.0.0";
const SERVER_IP = process.env.SERVER_IP || "flaremc.zanity.net:19121";
const DISCORD_URL = process.env.DISCORD_URL || "https://discord.gg/85HKV4jasU";
const DB_FILE = process.env.DATABASE_FILE || path.join(__dirname, "data", "flaremc.sqlite");

fs.mkdirSync(path.dirname(path.resolve(DB_FILE)), { recursive: true });
const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    username_lower TEXT NOT NULL,
    voted_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_votes_username_time ON votes(username_lower, voted_at);
  CREATE INDEX IF NOT EXISTS idx_votes_time ON votes(voted_at);
`);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "https://mc-heads.net", "https://api.mcsrvstat.us"],
      connectSrc: ["'self'", "https://api.mcsrvstat.us"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const voteLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment and try again." }
});

function cleanUsername(value) {
  if (typeof value !== "string") return null;
  const username = value.trim();
  // Java usernames are 3-16 chars, letters/numbers/underscore.
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return null;
  return username;
}

app.get("/api/config", (_req, res) => {
  res.json({ serverIp: SERVER_IP, discordUrl: DISCORD_URL });
});

app.get("/api/status", async (_req, res) => {
  try {
    const response = await fetch(`https://api.mcsrvstat.us/3/${encodeURIComponent(SERVER_IP)}`, {
      signal: AbortSignal.timeout(6500)
    });
    if (!response.ok) throw new Error("Status provider unavailable");
    const data = await response.json();
    res.set("Cache-Control", "public, max-age=20");
    res.json({
      online: Boolean(data.online),
      playersOnline: data.players?.online ?? 0,
      playersMax: data.players?.max ?? 0,
      version: data.version || "Unknown",
      motd: (data.motd?.clean || []).join(" ").slice(0, 180),
      checkedAt: new Date().toISOString()
    });
  } catch (_error) {
    res.status(200).json({
      online: false, playersOnline: 0, playersMax: 0,
      version: "Unavailable", motd: "", checkedAt: new Date().toISOString(),
      statusUnavailable: true
    });
  }
});

app.get("/api/vote/cooldown/:username", (req, res) => {
  const username = cleanUsername(req.params.username);
  if (!username) return res.status(400).json({ error: "Enter a valid Minecraft username (3–16 letters, numbers or underscores)." });
  const row = db.prepare(`
    SELECT voted_at FROM votes
    WHERE username_lower = ? AND datetime(voted_at) > datetime('now', '-24 hours')
    ORDER BY datetime(voted_at) DESC LIMIT 1
  `).get(username.toLowerCase());

  if (!row) return res.json({ canVote: true, remainingSeconds: 0 });
  const votedAt = new Date(row.voted_at.replace(" ", "T") + "Z").getTime();
  const remainingSeconds = Math.max(0, Math.ceil((votedAt + 24 * 60 * 60 * 1000 - Date.now()) / 1000));
  res.json({ canVote: remainingSeconds <= 0, remainingSeconds });
});

app.post("/api/vote", voteLimiter, (req, res) => {
  const username = cleanUsername(req.body?.username);
  if (!username) {
    return res.status(400).json({ error: "Enter a valid Minecraft username (3–16 letters, numbers or underscores)." });
  }

  const normalized = username.toLowerCase();
  const existing = db.prepare(`
    SELECT voted_at FROM votes
    WHERE username_lower = ? AND datetime(voted_at) > datetime('now', '-24 hours')
    ORDER BY datetime(voted_at) DESC LIMIT 1
  `).get(normalized);

  if (existing) {
    const votedAt = new Date(existing.voted_at.replace(" ", "T") + "Z").getTime();
    const remainingSeconds = Math.max(1, Math.ceil((votedAt + 24 * 60 * 60 * 1000 - Date.now()) / 1000));
    return res.status(429).json({ error: "This username has already voted recently.", remainingSeconds });
  }

  db.prepare("INSERT INTO votes (username, username_lower) VALUES (?, ?)").run(username, normalized);
  res.status(201).json({
    success: true,
    username,
    avatarUrl: `https://mc-heads.net/avatar/${encodeURIComponent(username)}/64`,
    message: "Your vote has been recorded. Thanks for supporting FlareMC!"
  });
});

app.get("/api/leaderboard", (req, res) => {
  const period = req.query.period === "all" ? "all" : "monthly";
  const timeFilter = period === "monthly" ? "WHERE datetime(voted_at) >= datetime('now', 'start of month')" : "";
  const rows = db.prepare(`
    SELECT username, COUNT(*) AS votes
    FROM votes
    ${timeFilter}
    GROUP BY username_lower
    ORDER BY votes DESC, MIN(datetime(voted_at)) ASC
    LIMIT 10
  `).all();
  res.json({ period, entries: rows });
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, HOST, () => {
  console.log(`FlareMC website listening on http://${HOST}:${PORT}`);
  console.log(`Minecraft server: ${SERVER_IP}`);
});
